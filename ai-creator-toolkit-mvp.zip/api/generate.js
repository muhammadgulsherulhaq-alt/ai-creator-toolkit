// Vercel serverless function.
// Add OPENAI_API_KEY as an environment variable in your hosting dashboard.
// Never put the API key inside index.html or script.js.

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({error:"Method not allowed"});
  try {
    const {topic, platform, tone} = req.body || {};
    if (!topic) return res.status(400).json({error:"Topic is required"});
    if (!process.env.OPENAI_API_KEY) return res.status(500).json({error:"OPENAI_API_KEY is not configured"});

    const prompt = `You are an expert social media strategist.
Create a concise creator content pack.
Topic: ${topic}
Platform: ${platform || "YouTube Shorts"}
Tone: ${tone || "Curiosity"}

Return ONLY valid JSON with exactly these keys:
titles: array of 10 short clickable titles,
hooks: array of 10 strong opening hooks,
thumbnails: array of 3 very short thumbnail text ideas.
Avoid fake claims, spammy wording, and excessive punctuation.`;

    const response = await fetch("https://api.openai.com/v1/responses", {
      method:"POST",
      headers:{
        "Content-Type":"application/json",
        "Authorization":`Bearer ${process.env.OPENAI_API_KEY}`
      },
      body:JSON.stringify({
        model:"gpt-5-mini",
        input:prompt
      })
    });

    if(!response.ok) {
      const detail = await response.text();
      return res.status(response.status).json({error:detail});
    }

    const data = await response.json();
    const text = data.output_text || "";
    const clean = text.replace(/^```json\s*/i,"").replace(/\s*```$/,"").trim();
    return res.status(200).json(JSON.parse(clean));
  } catch(e) {
    return res.status(500).json({error:e.message});
  }
}
